package com.example.disenio_de_pantalla

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
